TIC TAC TOE WEB

Isi:
- index.html
- style.css
- script.js
- music.wav

Cara menjalankan:
1. Ekstrak ZIP.
2. Buka folder di VS Code.
3. Klik dua kali index.html atau jalankan dengan Live Server.
4. Game memiliki skor X dan O.
5. Timer dimulai dari 200 detik.
6. Musik dapat ON/OFF melalui tombol Musik.
7. Setelah ronde selesai, tekan Ronde Baru untuk bermain lagi.

Catatan:
Browser modern biasanya memblokir autoplay audio sebelum pengguna berinteraksi.
Karena itu musik akan mulai setelah tombol/kotak game diklik atau tombol Ronde Baru ditekan.
