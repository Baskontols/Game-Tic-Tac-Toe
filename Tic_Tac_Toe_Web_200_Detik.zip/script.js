const cells = document.querySelectorAll(".cell");
const statusText = document.getElementById("status");
const scoreXEl = document.getElementById("scoreX");
const scoreOEl = document.getElementById("scoreO");
const timerEl = document.getElementById("timer");
const newRoundBtn = document.getElementById("newRound");
const resetGameBtn = document.getElementById("resetGame");
const musicBtn = document.getElementById("musicBtn");
const bgMusic = document.getElementById("bgMusic");

const WINNING_COMBOS = [
  [0,1,2], [3,4,5], [6,7,8],
  [0,3,6], [1,4,7], [2,5,8],
  [0,4,8], [2,4,6]
];

let board = Array(9).fill("");
let currentPlayer = "X";
let gameActive = true;
let timeLeft = 200;
let scoreX = 0;
let scoreO = 0;
let timerInterval;
let musicOn = true;

function updateScore() {
  scoreXEl.textContent = scoreX;
  scoreOEl.textContent = scoreO;
}

function startTimer() {
  clearInterval(timerInterval);
  timeLeft = 200;
  timerEl.textContent = timeLeft;

  timerInterval = setInterval(() => {
    if (!gameActive) return;

    timeLeft--;
    timerEl.textContent = timeLeft;

    if (timeLeft <= 0) {
      endByTime();
    }
  }, 1000);
}

function startRound() {
  board = Array(9).fill("");
  currentPlayer = "X";
  gameActive = true;
  statusText.textContent = "Giliran Pemain X";

  cells.forEach(cell => {
    cell.textContent = "";
    cell.className = "cell";
    cell.disabled = false;
  });

  startTimer();
}

function getResult() {
  for (const combo of WINNING_COMBOS) {
    const [a,b,c] = combo;
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return { winner: board[a], combo };
    }
  }

  if (board.every(Boolean)) {
    return { winner: "DRAW", combo: [] };
  }

  return null;
}

function handleMove(index) {
  if (!gameActive || board[index]) return;

  // Coba mulai musik setelah interaksi pengguna (aturan autoplay browser).
  if (musicOn && bgMusic.paused) {
    bgMusic.play().catch(() => {});
  }

  board[index] = currentPlayer;
  cells[index].textContent = currentPlayer;
  cells[index].classList.add(currentPlayer.toLowerCase());
  cells[index].disabled = true;

  const result = getResult();

  if (result) {
    gameActive = false;
    clearInterval(timerInterval);

    if (result.winner === "X") {
      scoreX++;
      statusText.textContent = "🎉 Pemain X menang!";
    } else if (result.winner === "O") {
      scoreO++;
      statusText.textContent = "🎉 Pemain O menang!";
    } else {
      statusText.textContent = "🤝 Seri!";
    }

    result.combo.forEach(i => cells[i].classList.add("win"));
    updateScore();

    setTimeout(() => {
      if (confirm("Ronde selesai. Mulai ronde baru?")) startRound();
    }, 250);

    return;
  }

  currentPlayer = currentPlayer === "X" ? "O" : "X";
  statusText.textContent = `Giliran Pemain ${currentPlayer}`;
}

function endByTime() {
  gameActive = false;
  clearInterval(timerInterval);
  cells.forEach(cell => cell.disabled = true);

  if (scoreX > scoreO) {
    statusText.textContent = "⏰ Waktu habis — X unggul!";
  } else if (scoreO > scoreX) {
    statusText.textContent = "⏰ Waktu habis — O unggul!";
  } else {
    statusText.textContent = "⏰ Waktu habis — skor seri!";
  }
}

cells.forEach(cell => {
  cell.addEventListener("click", () => handleMove(Number(cell.dataset.index)));
});

newRoundBtn.addEventListener("click", () => {
  startRound();
  if (musicOn) bgMusic.play().catch(() => {});
});

resetGameBtn.addEventListener("click", () => {
  scoreX = 0;
  scoreO = 0;
  updateScore();
  startRound();
});

musicBtn.addEventListener("click", () => {
  musicOn = !musicOn;

  if (musicOn) {
    musicBtn.textContent = "🔊 Musik: ON";
    bgMusic.play().catch(() => {});
  } else {
    musicBtn.textContent = "🔇 Musik: OFF";
    bgMusic.pause();
  }
});

// Pastikan musik berhenti saat halaman ditutup.
window.addEventListener("beforeunload", () => {
  clearInterval(timerInterval);
});

updateScore();
startRound();
